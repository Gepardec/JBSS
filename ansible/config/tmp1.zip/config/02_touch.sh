#!/bin/sh

date >  tmp1.txt
